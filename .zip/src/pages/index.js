import TimesheetApp from '../components/TimesheetApp';
export default function Home() {
  return <TimesheetApp />;
}