// src/pages/admin/user-management.js
import AdminUserManagement from '../../components/AdminUserManagement';

export default function UserManagementPage() {
  return <AdminUserManagement />;
}
