// pages/timesheet-daily.js
import TimesheetApp from '../components/TimesheetApp';

export default function DailyView() {
  return <TimesheetApp />;
}