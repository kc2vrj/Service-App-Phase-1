"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/404";
exports.ids = ["pages/404"];
exports.modules = {

/***/ "./src/pages/404.js":
/*!**************************!*\
  !*** ./src/pages/404.js ***!
  \**************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ Custom404)\n/* harmony export */ });\n/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-runtime */ \"react/jsx-runtime\");\n/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);\n\nfunction Custom404() {\n    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(\"div\", {\n        className: \"min-h-screen flex items-center justify-center bg-gray-50\",\n        __source: {\n            fileName: \"/home/code/timsheet-new/src/pages/404.js\",\n            lineNumber: 3,\n            columnNumber: 7\n        },\n        __self: this,\n        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(\"div\", {\n            className: \"text-center\",\n            __source: {\n                fileName: \"/home/code/timsheet-new/src/pages/404.js\",\n                lineNumber: 4,\n                columnNumber: 9\n            },\n            __self: this,\n            children: [\n                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(\"h1\", {\n                    className: \"text-4xl font-bold text-gray-900 mb-4\",\n                    __source: {\n                        fileName: \"/home/code/timsheet-new/src/pages/404.js\",\n                        lineNumber: 5,\n                        columnNumber: 11\n                    },\n                    __self: this,\n                    children: \"404 - Page Not Found\"\n                }),\n                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(\"p\", {\n                    className: \"text-gray-600\",\n                    __source: {\n                        fileName: \"/home/code/timsheet-new/src/pages/404.js\",\n                        lineNumber: 6,\n                        columnNumber: 11\n                    },\n                    __self: this,\n                    children: \"The page you're looking for doesn't exist.\"\n                }),\n                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(\"a\", {\n                    href: \"/\",\n                    className: \"mt-4 inline-block text-blue-600 hover:text-blue-800\",\n                    __source: {\n                        fileName: \"/home/code/timsheet-new/src/pages/404.js\",\n                        lineNumber: 7,\n                        columnNumber: 11\n                    },\n                    __self: this,\n                    children: \"Return Home\"\n                })\n            ]\n        })\n    }));\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvcGFnZXMvNDA0LmpzLmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7QUFBZSxRQUFRLENBQUNBLFNBQVMsR0FBRyxDQUFDO0lBQ2pDLE1BQU0sc0VBQ0hDLENBQUc7UUFBQ0MsU0FBUyxFQUFDLENBQTBEOzs7Ozs7O3dGQUN0RUQsQ0FBRztZQUFDQyxTQUFTLEVBQUMsQ0FBYTs7Ozs7Ozs7cUZBQ3pCQyxDQUFFO29CQUFDRCxTQUFTLEVBQUMsQ0FBdUM7Ozs7Ozs7OEJBQUMsQ0FBb0I7O3FGQUN6RUUsQ0FBQztvQkFBQ0YsU0FBUyxFQUFDLENBQWU7Ozs7Ozs7OEJBQUMsQ0FBMEM7O3FGQUN0RUcsQ0FBQztvQkFBQ0MsSUFBSSxFQUFDLENBQUc7b0JBQUNKLFNBQVMsRUFBQyxDQUFxRDs7Ozs7Ozs4QkFBQyxDQUU1RTs7Ozs7QUFJUixDQUFDIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vdGltZXNoZWV0LWFwcC8uL3NyYy9wYWdlcy80MDQuanM/NzU4NyJdLCJzb3VyY2VzQ29udGVudCI6WyJleHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBDdXN0b200MDQoKSB7XHJcbiAgICByZXR1cm4gKFxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1pbi1oLXNjcmVlbiBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBiZy1ncmF5LTUwXCI+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlclwiPlxyXG4gICAgICAgICAgPGgxIGNsYXNzTmFtZT1cInRleHQtNHhsIGZvbnQtYm9sZCB0ZXh0LWdyYXktOTAwIG1iLTRcIj40MDQgLSBQYWdlIE5vdCBGb3VuZDwvaDE+XHJcbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNjAwXCI+VGhlIHBhZ2UgeW91J3JlIGxvb2tpbmcgZm9yIGRvZXNuJ3QgZXhpc3QuPC9wPlxyXG4gICAgICAgICAgPGEgaHJlZj1cIi9cIiBjbGFzc05hbWU9XCJtdC00IGlubGluZS1ibG9jayB0ZXh0LWJsdWUtNjAwIGhvdmVyOnRleHQtYmx1ZS04MDBcIj5cclxuICAgICAgICAgICAgUmV0dXJuIEhvbWVcclxuICAgICAgICAgIDwvYT5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcbiAgICApO1xyXG4gIH0iXSwibmFtZXMiOlsiQ3VzdG9tNDA0IiwiZGl2IiwiY2xhc3NOYW1lIiwiaDEiLCJwIiwiYSIsImhyZWYiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./src/pages/404.js\n");

/***/ }),

/***/ "react/jsx-runtime":
/*!************************************!*\
  !*** external "react/jsx-runtime" ***!
  \************************************/
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./src/pages/404.js"));
module.exports = __webpack_exports__;

})();